# Phi Bao Nam Shop (GitHub Pages)

## Có gì trong bộ này
- `index.html`: giao diện shop anime tím đen, danh mục, giá, tìm kiếm/lọc, popup tạo nội dung đơn và liên hệ.
- `anime-hero.png`: ảnh nền anime.
- Trang không giả lập thanh toán thành công. Khách cần liên hệ shop, chuyển khoản, rồi gửi bill; chủ shop tự xác nhận.

## Đưa lên GitHub Pages
1. Mở repository GitHub của bạn.
2. Tải `index.html` và `anime-hero.png` lên cùng thư mục gốc (nơi file `README.md` hoặc các file khác đang nằm).
3. Nhấn **Commit changes**.
4. Vào **Settings → Pages**.
5. Ở **Build and deployment**, chọn **Deploy from a branch**.
6. Chọn branch `main` và folder `/(root)`, nhấn **Save**.
7. Đợi GitHub Pages build xong rồi mở URL hiển thị trong phần Pages.

## Trước khi công khai
- Kiểm tra lại thông tin tài khoản ngân hàng, tên chủ tài khoản, Zalo và Telegram.
- Giá hiện tại là giá mẫu theo yêu cầu; hãy xác nhận chính xác số lượng/điều kiện từng gói.
- Nút đặt hàng chỉ tạo nội dung tin nhắn để khách sao chép và liên hệ. Nó không tạo đơn trên máy chủ và không xác nhận thanh toán.
- GitHub Pages là hosting tĩnh. Muốn tự nhận đơn, xác minh chuyển khoản, gửi thông báo hoặc giao dịch tự động, cần backend/dịch vụ bên ngoài và tích hợp an toàn.
- Không đưa mật khẩu, OTP hoặc API secret vào file HTML công khai.
